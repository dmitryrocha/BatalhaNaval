package Avaliacao03;

import java.util.Random;
import java.util.Scanner;

public class Barcos {

    public static Scanner sc = new Scanner(System.in);

    public static String[][] posicaoBarcosPC(String player, String[][] tabuleiro) {
        String[][] tabuleiroNovo = tabuleiro;
        boolean finalizou = false, porCima = false;
        int x = 0, y = 0, p = 0, tamanho = 5;
        Random rd = new Random();

        //Porta-aviões
        x = rd.nextInt(5);
        y = rd.nextInt(5);
        p = rd.nextInt(2);
        while (tamanho != 0) {
            if (p == 1) {
                if (y == 9) {
                    tabuleiroNovo[x][y] = "|XXXXX|";
                } else {
                    tabuleiroNovo[x][y] = "|XXXXX";
                    System.out.println("PAEntrou!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                }
                x++;
            }
            if (p == 2) {
                if (y == 9) {
                    tabuleiroNovo[x][y] = "|XXXXX|";
                } else {
                    tabuleiroNovo[x][y] = "|XXXXX";
                }
                y++;
            }
            tamanho--;
        }

        Mapa.imprimirTabuleiro(tabuleiroNovo, player);

        tabuleiro = tabuleiroNovo;

        //Navio-tanque
        x = rd.nextInt(6);
        y = rd.nextInt(6);
        p = rd.nextInt(2);
        tamanho = 4;
        while (porCima == true) {


            while (tamanho != 0) {
                if (tabuleiroNovo[x][y].equals("|XXXXX") || tabuleiroNovo[x][y].equals("|XXXXX|")) {

                    x = rd.nextInt(6);
                    y = rd.nextInt(6);
                    p = rd.nextInt(2);
                    tamanho = -3;
                } else {
                    if (p == 1) {
                        if (y == 9) {
                            tabuleiroNovo[x][y] = "|XXXXX|";
                        }
                        tabuleiroNovo[x][y] = "|XXXXX";
                        System.out.println("NT!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        x++;
                    }
                    if (p == 2) {
                        if (y == 9) {
                            tabuleiroNovo[x][y] = "|XXXXX|";
                        }
                        tabuleiroNovo[x][y] = "|XXXXX";
                        y++;
                    }
                    tamanho--;
                }


                if (tamanho == 0) {
                    porCima = false;
                } else if (tamanho <= -3) {
                    porCima = true;
                    tamanho = 4;
                    tabuleiroNovo = tabuleiro;
                }
            }
        }

        Mapa.imprimirTabuleiro(tabuleiroNovo, player);


        return tabuleiroNovo;

    }


    public static String[][] posicaoBarcos(String player, String[][] tabuleiro) {
        String[][] tabuleiroNovo = tabuleiro;
        boolean finalizou = false, porCima = false;
        int x = 0, y = 0, p = 0, tamanho = 5;
        /*  (1) porta-aviões (cinco quadrados)
            (2) navios-tanque (quatro quadrados)
            (3) contratorpedeiros (três quadrados)
            (4) submarinos (dois quadrados)
        */


        //Porta-Aviões
        do {
            do {
                System.out.println("Seu porta-aviões estará na vertical ou horizontal?\nDigite 1 para vertical ou 2 para horizontal");
                p = sc.nextInt();
            } while (p < 1 || p > 2);
            do {
                System.out.println("Favor escolher a linha onde seu porta-aviões estará:\nDigite um número de 0 a 9");
                x = sc.nextInt();
                if (p == 1) {
                    if (x + 4 > 9) {
                        System.out.println("O valor escolhido extrapola o tabuleiro, favor tentar novamente");
                        x = -1;
                    }
                }
            } while (x < 0 || x > 9);
            do {
                System.out.println("Favor escolher a coluna onde seu porta-aviões estará:\nDigite um número de 0 a 9");
                y = sc.nextInt();
                if (p == 2) {
                    if (y + 4 > 9) {
                        System.out.println("O valor escolhido extrapola o tabuleiro, favor tentar novamente");
                        y = -1;
                    }
                }
            } while (y < 0 || y > 9);

            while (tamanho != 0) {

                if (p == 1) {
                    if (y == 9) {
                        tabuleiroNovo[x][y] = "|XXXXX|";
                    }
                    tabuleiroNovo[x][y] = "|XXXXX";
                    x++;
                } else if (p == 2) {
                    if (y == 9) {
                        tabuleiroNovo[x][y] = "|XXXXX|";
                    }
                    tabuleiroNovo[x][y] = "|XXXXX";
                    y++;
                }
                tamanho--;
            }
            finalizou = true;
        }while(!finalizou);

            Mapa.imprimirTabuleiro(tabuleiroNovo, player);

            x = -1;
            y = -1;
            p = -1;
            tamanho = 4;
            finalizou = false;

            //Navios-tanque (quatro quadrados)
            do {
                do {
                    System.out.println("Seu navio-tanque estará na vertical ou horizontal?\nDigite 1 para vertical ou 2 para horizontal");
                    p = sc.nextInt();
                } while (p < 1 || p > 2);
                do {
                    System.out.println("Favor escolher a linha onde seu navio-tanque estará:\nDigite um número de 0 a 9");
                    x = sc.nextInt();
                    if (p == 1) {
                        if (x + 3 > 9) {
                            System.out.println("O valor escolhido extrapola o tabuleiro, favor tentar novamente");
                            x = -1;
                        }
                    }
                } while (x < 0 || x > 9);
                do {
                    System.out.println("Favor escolher a coluna onde seu navio-tanque estará:\nDigite um número de 0 a 9");
                    y = sc.nextInt();
                    if (p == 2) {
                        if (y + 3 > 9) {
                            System.out.println("O valor escolhido extrapola o tabuleiro, favor tentar novamente");
                            y = -1;
                        }
                    }
                } while (y < 0 || y > 9);

                while (tamanho != 0) {
                    if (tabuleiroNovo[x][y].equals("|XXXXX|") || tabuleiroNovo[x][y].equals("|XXXXX")) {
                        System.out.println("Este espaço já está ocupado. Favor esolher os locais novamente");
                        tamanho = 4;
                        porCima = true;
                    } else {
                        if (p == 1) {
                            if (y == 9) {
                                tabuleiroNovo[x][y] = "|XXXXX|";
                            }
                            tabuleiroNovo[x][y] = "|XXXXX";
                            x++;
                        } else if (p == 2) {
                            if (y == 9) {
                                tabuleiroNovo[x][y] = "|XXXXX|";
                            }
                            tabuleiroNovo[x][y] = "|XXXXX";
                            y++;
                        }
                        tamanho--;
                    }


                }
                if(tamanho == 0){
                    porCima = false;
                } else if(tamanho == 4) {
                    porCima = true;
                }

            }while (porCima);


                x = -1;
                y = -1;
                p = -1;
                finalizou = false;

                Mapa.imprimirTabuleiro(tabuleiroNovo, player);

                //Contratorpedeiro (três quadrados)
                do {
                    do {
                        System.out.println("Favor escolher a linha onde seu contratorpedeiro estará:\nDigite um número de 0 a 9");
                        x = sc.nextInt();
                        System.out.println("Favor escolher a coluna onde seu contratorpedeiro estará:\nDigite um número de 0 a 9");
                        y = sc.nextInt();
                        System.out.println("Seu contratorpedeiro estará na vertical ou horizontal?\nDigite 1 para vertical ou 2 para horizontal");
                        p = sc.nextInt();
                        if (p == 1) {
                            if (x + 3 > 9) {
                                System.out.println("O valor escolhido extrapola o tabuleiro, favor tentar novamente");
                                x = -1;
                            }
                        } else if (p == 2) {
                            if (y + 3 > 9) {
                                System.out.println("O valor escolhido extrapola o tabuleiro, favor tentar novamente");
                                y = -1;
                            }
                        }
                    } while ((x < 0 || x > 9) && (y < 0 || y > 9) && (p < 1 || p > 2));
                    while (tamanho != 0) {
                        if (tabuleiroNovo[x][y].equals("|XXXXX|") || tabuleiroNovo[x][y].equals("|XXXXX")) {
                            System.out.println("Este espaço já está ocupado. Favor esolher os locais novamente");
                            tamanho = 0;
                            porCima = true;
                        } else {
                            if (p == 1) {
                                if (y == 9) {
                                    tabuleiroNovo[x][y] = "|XXXXX|";
                                }
                                tabuleiroNovo[x][y] = "|XXXXX";
                                x++;
                            } else if (p == 2) {
                                if (y == 9) {
                                    tabuleiroNovo[x][y] = "|XXXXX|";
                                }
                                tabuleiroNovo[x][y] = "|XXXXX";
                                y++;
                            }
                            tamanho--;
                        }
                        if (tamanho == 0)
                            finalizou = true;
                    }


                } while (!finalizou);

                if (porCima) {
                    tabuleiroNovo = tabuleiro;
                    return tabuleiroNovo;
                } else {
                    tamanho = 2;
                }

                x = -1;
                y = -1;
                p = -1;
                finalizou = false;
                Mapa.imprimirTabuleiro(tabuleiroNovo, player);

                //Submarinos (dois quadrados)
                do {
                    do {
                        System.out.println("Favor escolher a linha onde seu submarino estará:\nDigite um número de 0 a 9");
                        x = sc.nextInt();
                        System.out.println("Favor escolher a coluna onde seu submarino estará:\nDigite um número de 0 a 9");
                        y = sc.nextInt();
                        System.out.println("Seu submarino estará na vertical ou horizontal?\nDigite 1 para vertical ou 2 para horizontal");
                        p = sc.nextInt();
                        if (p == 1) {
                            if (x + 2 > 9) {
                                System.out.println("O valor escolhido extrapola o tabuleiro, favor tentar novamente");
                                x = -1;
                            }
                        } else if (p == 2) {
                            if (y + 2 > 9) {
                                System.out.println("O valor escolhido extrapola o tabuleiro, favor tentar novamente");
                                y = -1;
                            }
                        }
                    } while ((x < 0 || x > 9) && (y < 0 || y > 9) && (p < 1 || p > 2));
                    while (tamanho != 0) {
                        if (tabuleiroNovo[x][y].equals("|XXXXX|") || tabuleiroNovo[x][y].equals("|XXXXX")) {
                            System.out.println("Este espaço já está ocupado. Favor esolher os locais novamente");
                            tamanho = 0;
                            porCima = true;
                        } else {
                            if (p == 1) {
                                if (y == 9) {
                                    tabuleiroNovo[x][y] = "|XXXXX|";
                                }
                                tabuleiroNovo[x][y] = "|XXXXX";
                                x++;
                            } else if (p == 2) {
                                if (y == 9) {
                                    tabuleiroNovo[x][y] = "|XXXXX|";
                                }
                                tabuleiroNovo[x][y] = "|XXXXX";
                                y++;
                            }
                            tamanho--;
                        }
                        if (tamanho == 0)
                            finalizou = true;
                    }


                } while (!finalizou);

                if (porCima) {
                    tabuleiroNovo = tabuleiro;
                    return tabuleiroNovo;
                } else {
                    tamanho = 3;
                }

                x = -1;
                y = -1;
                p = -1;
                finalizou = false;

                return tabuleiroNovo;


    }
}
