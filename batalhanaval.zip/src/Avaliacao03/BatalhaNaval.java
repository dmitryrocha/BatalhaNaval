package Avaliacao03;

import java.util.Scanner;

public class BatalhaNaval {

    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int jogadores = bemVindo();
        String[][] tabuleiro = new String[10][10];

        iniciarJogo(jogadores);



    }

    public static int bemVindo() {
        int qtd = -1;
        System.out.println("Bem vindo(a) à Batalha naval");
        barco();
        do {
            System.out.println("Favor informar o número de jogadores\n(1) - Para jogar contra o computador\n(2) - Para jogar contra outro jogador");
            qtd = sc.nextInt();
        } while(qtd<1 || qtd>2);
        return qtd;
    }

    public static void iniciarJogo(int qtd) {
        int count = 0;
        String P1 = "Jogador 1", P2 = null;
        String[][] tabuleiroP1 = Mapa.criarTabuleiro(P1);

        if(qtd == 1) {
            P2 = "Computador";
        } else {
            P2 = "Jogador 2";
        }
        String[][] tabuleiroP2 = Mapa.criarTabuleiro(P2);



        tabuleiroP1 = Barcos.posicaoBarcos(P1,tabuleiroP1);
        Mapa.imprimirTabuleiro(tabuleiroP1,P1);
        System.out.println("\nPosicionamento do "+P1+" finalizado");
        if(qtd == 1){
            tabuleiroP2 = Barcos.posicaoBarcosPC(P2, tabuleiroP2);
        } else {
            tabuleiroP2 = Barcos.posicaoBarcos(P2, tabuleiroP2);
        }
        System.out.println("Posicionamento do "+P2+" finalizado");


    }





    public static void barco() {
        System.out.println("                                       __  o");
        System.out.println("                                      /  |/");
        System.out.println("                                    _/___|___________");
        System.out.println("                                   /  _______      __\\");
        System.out.println("                                   /  _______      __\\");
        System.out.println("   _______                        /  /_o_||__|    |");
        System.out.println("    \\_\\_\\_\\______________________/___             |");
        System.out.println("             \\                       \\____________|______________");
        System.out.println("              \\     ||                                           |");
        System.out.println("               \\  +_||_+       () () ()                      ____|");
        System.out.println("                \\                                             |");
        System.out.println("                 \\     _  ,,          _                      /");
        System.out.println(" ^^^^^^^^^^^^^^^^ \\_.=\'' )\''  \''-._____,' \'';__________________ /_^^^^^^^^");
        System.out.println("   ^^^^  ^^^^                                              \\__|==% ^^");
        System.out.println("  ^^         ^^^^^^^^       ^^^^ ^^^ ^^^^^      ^^^^^^^^^^ ^      ^^^^");
        System.out.println("^^^   ^^^^          ^^^^^^^^^^^^          ^^^^     ^^       ^^^^^");


    }
}
